def greet(name):
    return f"Hello, {name}!"
